<?php

require_once('genres.php');
require_once('keywords.php');